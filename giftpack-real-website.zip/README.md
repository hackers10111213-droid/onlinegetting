# Gift Pack — Real Full-Stack Website

This is a **real backend/database website starter**, not a browser-only demo.

## Included

- Real user registration and login
- Password hashing with bcrypt
- JWT authentication in HTTP-only cookies
- User/Admin role separation
- PostgreSQL database
- Gift Pack CRUD for Admin
- User order creation
- Transaction ID / payment proof submission
- Admin order approval/rejection
- User order history and status
- User profile and password change
- Admin user management
- Admin settings for JazzCash/social link/site name
- Responsive mobile/tablet/desktop UI
- Security headers and basic rate limiting

## Important

This package is a deployable application codebase, but it is **not already hosted on the internet**. A real public website still needs:

1. A domain name
2. A server/VPS or managed hosting
3. PostgreSQL database
4. HTTPS/SSL
5. Production environment variables
6. Real JazzCash merchant/payment integration if you want automatic payment verification
7. Optional SMS/WhatsApp provider credentials if notifications are required

The app does not contain or expose real payment credentials.

## Run locally

1. Install Node.js 20+ and PostgreSQL.
2. Create a PostgreSQL database named `giftpack`.
3. Copy `.env.example` to `.env` and set a strong `JWT_SECRET`, database URL and admin password.
4. Install dependencies:

```bash
npm install
```

5. Initialize database:

```bash
npm run db:init
```

6. Start:

```bash
npm start
```

Open `http://localhost:3000`.

## Production

Use a process manager such as systemd/PM2, put Nginx/Caddy in front, enable HTTPS, set `COOKIE_SECURE=true`, use a managed PostgreSQL database, and keep `.env` outside source control.

## Payment wording

The default workflow records a user's payment submission and sends it to Admin for verification. It does **not** falsely promise a gift merely because a transaction ID was entered.

For an actual paid gift-pack purchase, the pack itself should be clearly described (contents, price, delivery/eligibility terms, refund policy, etc.).
