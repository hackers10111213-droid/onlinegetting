require('dotenv').config();
const fs = require('fs');
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
(async () => {
  const schema = fs.readFileSync(require('path').join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(schema);
  const bcrypt = require('bcryptjs');
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (email && password && !password.includes('CHANGE_THIS')) {
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO users (name,email,password_hash,role) VALUES ($1,$2,$3,'admin')
       ON CONFLICT (email) DO UPDATE SET role='admin'`,
      ['Administrator', email.toLowerCase(), hash]
    );
  }
  console.log('Database initialized.');
  await pool.end();
})().catch(err => { console.error(err); process.exit(1); });
