require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false });

function sign(user) {
  return jwt.sign({ id: user.id, role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
}
function auth(req, res, next) {
  try {
    const token = req.cookies.giftpack_token;
    if (!token) return res.status(401).json({ error: 'Login required.' });
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { return res.status(401).json({ error: 'Session expired. Please login again.' }); }
}
function admin(req, res, next) {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  next();
}
function sendError(res, err) {
  console.error(err);
  res.status(500).json({ error: 'Server error. Please try again.' });
}

app.use('/api', apiLimiter);

app.get('/api/settings/public', async (req,res) => {
  try {
    const r = await pool.query('SELECT site_name,jazzcash_account,social_url,social_message FROM site_settings WHERE id=1');
    res.json(r.rows[0] || {});
  } catch(e) { sendError(res,e); }
});

app.post('/api/auth/register', authLimiter, async (req,res) => {
  try {
    const {name,email,phone,password} = req.body;
    if (!name || !email || !password || password.length < 8) return res.status(400).json({error:'Name, email and a password of at least 8 characters are required.'});
    const normalized = email.trim().toLowerCase();
    const exists = await pool.query('SELECT id FROM users WHERE email=$1',[normalized]);
    if (exists.rowCount) return res.status(409).json({error:'Email already registered.'});
    const hash = await bcrypt.hash(password,12);
    const r = await pool.query('INSERT INTO users(name,email,phone,password_hash) VALUES($1,$2,$3,$4) RETURNING id,name,email,phone,role', [name.trim(),normalized,phone||null,hash]);
    const token = sign(r.rows[0]);
    res.cookie('giftpack_token', token, {httpOnly:true, secure:process.env.COOKIE_SECURE==='true', sameSite:'lax', maxAge:7*24*60*60*1000});
    res.status(201).json({user:r.rows[0]});
  } catch(e) { sendError(res,e); }
});

app.post('/api/auth/login', authLimiter, async (req,res) => {
  try {
    const {email,password} = req.body;
    const r = await pool.query('SELECT * FROM users WHERE email=$1',[String(email||'').trim().toLowerCase()]);
    if (!r.rowCount || !r.rows[0].active || !(await bcrypt.compare(password||'',r.rows[0].password_hash))) return res.status(401).json({error:'Invalid email or password.'});
    const u = r.rows[0];
    const token = sign(u);
    res.cookie('giftpack_token', token, {httpOnly:true, secure:process.env.COOKIE_SECURE==='true', sameSite:'lax', maxAge:7*24*60*60*1000});
    res.json({user:{id:u.id,name:u.name,email:u.email,phone:u.phone,role:u.role}});
  } catch(e) { sendError(res,e); }
});

app.post('/api/auth/logout', (req,res) => { res.clearCookie('giftpack_token'); res.json({ok:true}); });

app.get('/api/me', auth, async (req,res) => {
  try {
    const r = await pool.query('SELECT id,name,email,phone,role,active,created_at FROM users WHERE id=$1',[req.user.id]);
    res.json(r.rows[0]);
  } catch(e){sendError(res,e);}
});

app.put('/api/me', auth, async (req,res) => {
  try {
    const {name,phone} = req.body;
    const r = await pool.query('UPDATE users SET name=$1,phone=$2 WHERE id=$3 RETURNING id,name,email,phone,role',[String(name||'').trim(),phone||null,req.user.id]);
    res.json(r.rows[0]);
  } catch(e){sendError(res,e);}
});

app.put('/api/me/password', auth, async (req,res) => {
  try {
    const {currentPassword,newPassword}=req.body;
    if (!newPassword || newPassword.length<8) return res.status(400).json({error:'New password must be at least 8 characters.'});
    const r=await pool.query('SELECT password_hash FROM users WHERE id=$1',[req.user.id]);
    if (!(await bcrypt.compare(currentPassword||'',r.rows[0].password_hash))) return res.status(400).json({error:'Current password is incorrect.'});
    const hash=await bcrypt.hash(newPassword,12);
    await pool.query('UPDATE users SET password_hash=$1 WHERE id=$2',[hash,req.user.id]);
    res.json({ok:true});
  } catch(e){sendError(res,e);}
});

app.get('/api/packs', async (req,res)=>{
  try {
    const r=await pool.query('SELECT * FROM gift_packs WHERE active=true ORDER BY id DESC');
    res.json(r.rows);
  } catch(e){sendError(res,e);}
});

app.post('/api/orders', auth, async (req,res)=>{
  try {
    const {giftPackId,transactionId,paymentNote}=req.body;
    const p=await pool.query('SELECT * FROM gift_packs WHERE id=$1 AND active=true',[giftPackId]);
    if(!p.rowCount) return res.status(404).json({error:'Gift pack not found.'});
    const r=await pool.query('INSERT INTO orders(user_id,gift_pack_id,amount,transaction_id,payment_note) VALUES($1,$2,$3,$4,$5) RETURNING *',[req.user.id,giftPackId,p.rows[0].price,transactionId||null,paymentNote||null]);
    res.status(201).json(r.rows[0]);
  }catch(e){sendError(res,e);}
});

app.get('/api/orders', auth, async (req,res)=>{
  try {
    const r=await pool.query(`SELECT o.*,g.title AS pack_title FROM orders o JOIN gift_packs g ON g.id=o.gift_pack_id WHERE o.user_id=$1 ORDER BY o.id DESC`,[req.user.id]);
    res.json(r.rows);
  }catch(e){sendError(res,e);}
});

/* Admin */
app.get('/api/admin/stats', auth, admin, async(req,res)=>{
  try {
    const [u,o,p]=await Promise.all([
      pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role='user'"),
      pool.query("SELECT COUNT(*)::int AS n FROM orders"),
      pool.query("SELECT COUNT(*)::int AS n FROM gift_packs WHERE active=true")
    ]);
    res.json({users:u.rows[0].n,orders:o.rows[0].n,packs:p.rows[0].n});
  }catch(e){sendError(res,e);}
});

app.get('/api/admin/users', auth, admin, async(req,res)=>{
  try { const r=await pool.query('SELECT id,name,email,phone,role,active,created_at FROM users ORDER BY id DESC'); res.json(r.rows); } catch(e){sendError(res,e);}
});
app.put('/api/admin/users/:id', auth, admin, async(req,res)=>{
  try { const {name,phone,role,active}=req.body; const r=await pool.query('UPDATE users SET name=$1,phone=$2,role=$3,active=$4 WHERE id=$5 RETURNING id,name,email,phone,role,active',[name,phone||null,role==='admin'?'admin':'user',!!active,req.params.id]); res.json(r.rows[0]); }catch(e){sendError(res,e);}
});
app.delete('/api/admin/users/:id', auth, admin, async(req,res)=>{
  try { if(String(req.params.id)===String(req.user.id)) return res.status(400).json({error:'You cannot delete your own admin account.'}); await pool.query('DELETE FROM users WHERE id=$1',[req.params.id]); res.json({ok:true}); }catch(e){sendError(res,e);}
});

app.get('/api/admin/packs', auth, admin, async(req,res)=>{
  try { const r=await pool.query('SELECT * FROM gift_packs ORDER BY id DESC'); res.json(r.rows); }catch(e){sendError(res,e);}
});
app.post('/api/admin/packs', auth, admin, async(req,res)=>{
  try { const {title,description,price,imageUrl,active=true}=req.body; const r=await pool.query('INSERT INTO gift_packs(title,description,price,image_url,active) VALUES($1,$2,$3,$4,$5) RETURNING *',[title,description||'',Number(price),imageUrl||null,!!active]); res.status(201).json(r.rows[0]); }catch(e){sendError(res,e);}
});
app.put('/api/admin/packs/:id', auth, admin, async(req,res)=>{
  try { const {title,description,price,imageUrl,active}=req.body; const r=await pool.query('UPDATE gift_packs SET title=$1,description=$2,price=$3,image_url=$4,active=$5,updated_at=NOW() WHERE id=$6 RETURNING *',[title,description||'',Number(price),imageUrl||null,!!active,req.params.id]); res.json(r.rows[0]); }catch(e){sendError(res,e);}
});
app.delete('/api/admin/packs/:id', auth, admin, async(req,res)=>{
  try { await pool.query('DELETE FROM gift_packs WHERE id=$1',[req.params.id]); res.json({ok:true}); }catch(e){sendError(res,e);}
});

app.get('/api/admin/orders', auth, admin, async(req,res)=>{
  try { const r=await pool.query(`SELECT o.*,u.name AS user_name,u.email AS user_email,u.phone AS user_phone,g.title AS pack_title FROM orders o JOIN users u ON u.id=o.user_id JOIN gift_packs g ON g.id=o.gift_pack_id ORDER BY o.id DESC`); res.json(r.rows); }catch(e){sendError(res,e);}
});
app.put('/api/admin/orders/:id', auth, admin, async(req,res)=>{
  try { const {status,adminNote}=req.body; if(!['pending','approved','rejected'].includes(status)) return res.status(400).json({error:'Invalid status.'}); const r=await pool.query('UPDATE orders SET status=$1,admin_note=$2,updated_at=NOW() WHERE id=$3 RETURNING *',[status,adminNote||null,req.params.id]); res.json(r.rows[0]); }catch(e){sendError(res,e);}
});

app.get('/api/admin/settings', auth, admin, async(req,res)=>{
  try { const r=await pool.query('SELECT * FROM site_settings WHERE id=1'); res.json(r.rows[0]); }catch(e){sendError(res,e);}
});
app.put('/api/admin/settings', auth, admin, async(req,res)=>{
  try { const {siteName,jazzcashAccount,socialUrl,socialMessage}=req.body; const r=await pool.query('UPDATE site_settings SET site_name=$1,jazzcash_account=$2,social_url=$3,social_message=$4,updated_at=NOW() WHERE id=1 RETURNING *',[siteName,jazzcashAccount,socialUrl,socialMessage]); res.json(r.rows[0]); }catch(e){sendError(res,e);}
});

app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));

const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`Gift Pack server running on port ${port}`));
